Northstar Retail Group Mega Audit Package 2024

Synthetic classroom/demo audit package for the AI Audit Agent Dashboard.

IMPORTANT PARSER DESIGN:
- PDF is generated with selectable text and real text tables, not scanned images.
- DOCX files use actual Word paragraphs and tables.
- Graphs/images are included for realism, but every graph has matching machine-readable chart data in CSV/XLSX.
- CSV files repeat all detailed evidence so the frontend parser can read large populations without OCR.
- Intentional audit issues include missing vendor approvals, revenue cutoff gaps, inventory variances, IT access review gaps, compliance evidence gaps, and open remediation actions.

Recommended dashboard test questions:
1. What evidence supports Vendor Risk?
2. Which inventory locations have the largest variance exposure?
3. Which high-risk findings are overdue?
4. Turn the revenue cutoff exceptions into an action plan.
5. Explain which files support the compliance score.
